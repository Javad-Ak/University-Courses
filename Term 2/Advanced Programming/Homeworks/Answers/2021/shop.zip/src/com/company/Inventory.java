package com.company;

import java.util.HashMap;

public class Inventory {
    private final HashMap<Product, Integer> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product, Integer inStock) {
        if (products.containsKey(product)) {
            System.out.println("Product already exists!");
            return;
        }

        if (inStock <= 0) {
            System.out.println("Invalid Stock!");
            return;
        }

        products.put(product, inStock);
    }

    public void updateStock(Product product, Integer newStock) {
        if (newStock < 0) {
            System.out.println("Invalid Stock!");
            return;
        }

        if (newStock == 0) {
            products.remove(product);
            return;
        }

        products.replace(product, newStock);
    }

    public void removeProduct(Product product) {
        if (!products.containsKey(product)) {
            System.out.println("Product doesnt exists!");
            return;
        }

        products.remove(product);
    }

    public void printAllProducts() {
        int i=1;
        for (Product product : products.keySet()) {
            System.out.printf("%2d) %s \tin stock: %d\n", i, product.toString(), products.get(product));
            i++;
        }
    }

    public Product getProduct(int index) {
        if (index < 0 || index >= products.size()) return null;
        return (Product) products.keySet().toArray()[index];
    }

    public HashMap<Product, Integer> getProducts() {
        return products;
    }
}
