package com.company;

import java.util.ArrayList;

public class Basket {
    private final ArrayList<Product> products;

    public Basket() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void removeProduct(Product product) {
        if (!products.contains(product)) {
            System.out.println("Product doesnt exists!");
            return;
        }

        products.remove(product);
    }

    public void printAllProducts() {
        int i=1;
        for (Product product : products) {
            System.out.printf("%2d) %s\n", i, product.toString());
            i++;
        }
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public double balance() {
        double sum = 0.0;
        for (Product product : products) {
            sum += product.getPRICE();
        }

        return sum;
    }

    public Product getProduct(int index) {
        if (index < 0 || index >= products.size()) return null;
        return products.get(index);
    }
}
