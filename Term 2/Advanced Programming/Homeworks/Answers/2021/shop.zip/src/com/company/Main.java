package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Basket basket = new Basket();

        initProducts(inventory);

        loop(inventory, basket);
    }

    private static void loop(Inventory inventory, Basket basket) {
        inventory.printAllProducts();
        Scanner sc = new Scanner(System.in);

        System.out.println("\nGood morning, How can I help you? (add, remove, cart, balance, productsp, finish)");

        String string = sc.nextLine();
        while (true) {
            String[] command = string.split(" ");
            switch (command[0]) {
                case "add"-> {
                    if (command.length != 2) {
                        System.out.println("Invalid input!");
                    } else {
                        Product temp = inventory.getProduct(Integer.parseInt(command[1])-1);
                        if (temp == null) {
                            System.out.println("Product doesnt exist!");
                        } else {
                            basket.addProduct(temp);
                            inventory.updateStock(temp, inventory.getProducts().get(temp)-1);
                        }
                    }
                }
                case "remove" -> {
                    if (command.length != 2) {
                        System.out.println("Invalid input!");
                    } else {
                        Product temp = basket.getProduct(Integer.parseInt(command[1])-1);
                        basket.removeProduct(temp);
                        inventory.updateStock(temp, inventory.getProducts().get(temp)+1);
                    }
                }
                case "cart" -> {
                    if (command.length != 1) {
                        System.out.println("Invalid input!");
                    } else {
                        System.out.println("Items in cart: ");
                        basket.printAllProducts();
                    }
                }
                case "balance" -> {
                    if (command.length != 1) {
                        System.out.println("Invalid input!");
                    } else {
                        System.out.println("Basket Balance: " + basket.balance());
                    }
                }
                case "products" -> {
                    if (command.length != 1) {
                        System.out.println("Invalid input!");
                    } else {
                        inventory.printAllProducts();
                    }
                }
                case "finish" -> {
                    if (command.length != 1) {
                        System.out.println("Invalid input!");
                    } else {
                        System.out.println("It was a pleasure doing business with you");
                        return;
                    }
                }
            }

            string = sc.nextLine();
        }
    }

    private static void initProducts(Inventory inventory) {
        String[] categories = {"Vegetables", "Fruits", "Grains", "Seafood", "Meat", "Dairy", "Eggs"};

        Product product1 = new Product("Carrot", categories[0], 5, 20.0, "15-3-2020", "15-3-2021");
        Product product2 = new Product("Potato", categories[0], 10, 50.0, "1-4-2020", "1-8-2020");
        Product product3 = new Product("Eggshell", categories[6], 100, 40.0, "1-1-2020", "1-6-2020");
        Product product4 = new Product("Oats", categories[2], 70, 100.0, "1-6-2020", "1-1-2021");
        Product product5 = new Product("Salmon", categories[3], 150, 250.0, "1-1-2020", "1-2-2020");
        Product product6 = new Product("Red meat", categories[4], 800, 1000.0, "1-1-2020", "1-9-2020");
        Product product7 = new Product("Milk", categories[5], 1000, 20.0, "1-1-2020", "25-1-2020");
        Product product8 = new Product("Feta cheese", categories[5], 150, 10.0, "1-1-2020", "15-2-2020");

        inventory.addProduct(product1, 3);
        inventory.addProduct(product2, 10);
        inventory.addProduct(product3, 10);
        inventory.addProduct(product4, 10);
        inventory.addProduct(product5, 10);
        inventory.addProduct(product6, 10);
        inventory.addProduct(product7, 10);
        inventory.addProduct(product8, 10);
    }
}
