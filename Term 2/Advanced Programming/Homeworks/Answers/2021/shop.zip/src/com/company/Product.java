package com.company;

import java.time.LocalDate;
import java.util.Objects;

public class Product {
    private final String NAME;
    private final String CATEGORY;
    private final double WEIGHT;
    private final double PRICE;
    private final LocalDate MANUFACTURE_DATE;
    private final LocalDate EXPIRATION_DATE;

    public Product(String name, String category, double weight, double price, String mDate, String eDate) {
        NAME = name;
        CATEGORY = category;
        WEIGHT = weight;
        PRICE = price;
        MANUFACTURE_DATE = LocalDate.of(Integer.parseInt(mDate.split("-")[2]), Integer.parseInt(mDate.split("-")[1]),
                Integer.parseInt(mDate.split("-")[0]));
        EXPIRATION_DATE = LocalDate.of(Integer.parseInt(eDate.split("-")[2]), Integer.parseInt(eDate.split("-")[1]),
                Integer.parseInt(eDate.split("-")[0]));
    }

    public double getPRICE() {
        return PRICE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Double.compare(product.WEIGHT, WEIGHT) == 0 && Double.compare(product.PRICE, PRICE) == 0 && Objects.equals(NAME, product.NAME) && Objects.equals(CATEGORY, product.CATEGORY) && Objects.equals(MANUFACTURE_DATE, product.MANUFACTURE_DATE) && Objects.equals(EXPIRATION_DATE, product.EXPIRATION_DATE);
    }

    @Override
    public int hashCode() {
        return Objects.hash(NAME, CATEGORY, WEIGHT, PRICE, MANUFACTURE_DATE, EXPIRATION_DATE);
    }

    @Override
    public String toString() {
        return "Product{" +
                "NAME='" + NAME + '\'' +
                ", CATEGORY='" + CATEGORY + '\'' +
                ", WEIGHT=" + WEIGHT +
                ", PRICE=" + PRICE +
                ", MANUFACTURE_DATE=" + MANUFACTURE_DATE +
                ", EXPIRATION_DATE=" + EXPIRATION_DATE +
                '}';
    }
}
