package com.company;

import java.util.Scanner;

public class YoungGirl extends BadCharacter {

    public YoungGirl() {
        super(75, 25, 1, 25);
    }

    @Override
    public void useAbility(ShareData data) {
        if (super.wantUseAbility(data)) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Write the name of the person you want to damage?");
            data.printAliveUsers(this);
            String desiredUser = scanner.next();
            Character desiredCharacter = data.getAliveCharacterByUser(desiredUser);
            desiredCharacter.injure(super.getAmountOfDamage());
            System.out.println(data.getUserByCharacter(desiredCharacter) + " was damaged by Young Girl");
        }
    }
}

