package com.company;

import java.util.Scanner;

public class AngryMan extends BadCharacter {
    private final int rangeOfDamage;


    public AngryMan() {
        super(75, 20, 1, 50);
        this.rangeOfDamage = 10;
    }

    @Override
    public void useAbility(ShareData data) {
        if (super.wantUseAbility(data)) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Write the name of the person you want to damage?");
            data.printNearAliveUsers(this, rangeOfDamage);
            String desiredUser = scanner.next();
            Character desiredCharacter = data.getAliveCharacterByUser(desiredUser);
            desiredCharacter.injure(super.getAmountOfDamage());
        }
    }
}
