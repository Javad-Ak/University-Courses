package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class GameManager {
    private final int numberOfRounds;
    private final int amountOfDamagePerRound;
    private final int timeSecondsBetweenTwoRounds;
    private final int numberOfPlayers;
    private final ShareData shareData;
    private int roundNumber;
    public GameManager() {
        this.numberOfRounds = 10;
        this.amountOfDamagePerRound = 25;
        this.timeSecondsBetweenTwoRounds = 2;
        numberOfPlayers = 5;
        this.roundNumber = 1;
        this.shareData = new ShareData();
    }

    public void startGame() {
        getCharacterToUser();
        shareData.printUsersAndCharacters();
        while (!checkEndOfGame() && roundNumber <= numberOfRounds) {
            System.out.println("Green Light .....");
            for (Character character : shareData.getAliveCharacters()) {
                character.move(shareData);
            }
            try {
                Thread.sleep(timeSecondsBetweenTwoRounds * 1000L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            for (Character character:shareData.getAliveCharacters()){
                if (character.getTraveledDistance() == shareData.getDistance()){
                    shareData.addWinnerCharacter(character);
                }
            }
            if (checkEndOfGame()){
                break;
            }
            Character randomCharacter = shareData.getRandomAliveCharacter();
            randomCharacter.injure(amountOfDamagePerRound);
            System.out.println(shareData.getUserByCharacter(randomCharacter) + " was damaged by robot");
            shareData.getAliveCharacters().removeIf(character -> character.getHp() == 0);
            shareData.getAliveCharacters().removeIf(character -> character.getTraveledDistance() == shareData.getDistance());
            shareData.printAliveCharacters();
            System.out.println();
            shareData.getRandomAliveCharacter().useAbility(shareData);
            shareData.getAliveCharacters().removeIf(character -> character.getHp() == 0);
            shareData.printAliveCharacters();
            System.out.println();
            System.out.println("Red Light .....");
            roundNumber++;
        }
        System.out.println("Winners");
        int i =1;
        for (Character character : shareData.getWinnerCharacters()){
            System.out.println(i + ")" + shareData.getUserByCharacter(character));
            i++;
        }
    }


    public void getCharacterToUser() {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Character> characters = new ArrayList<>(shareData.getAliveCharacters());
        for (int i = 0; i < numberOfPlayers; i++) {
            System.out.println("Please enter your name:");
            String name = scanner.next();
            int randomNumber = new Random().nextInt(characters.size());
            shareData.addUserCharacter(characters.get(randomNumber), name);
            characters.remove(randomNumber);
        }


    }

    public boolean checkEndOfGame() {
        for (Character character : shareData.getAliveCharacters()) {
            if (character.getTraveledDistance() < shareData.getDistance()) {
                return false;
            }
        }
        return true;
    }
}

