package com.company;

public abstract class BadCharacter extends Character{
    private final int amountOfDamage;


    public BadCharacter(int hp, int speed, int numberOfTimesCanUseAbility,int amountOfDamage) {
        super(hp, speed, numberOfTimesCanUseAbility);
        this.amountOfDamage = amountOfDamage;

    }

    public int getAmountOfDamage() {
        return amountOfDamage;
    }

    @Override
    public abstract void useAbility(ShareData data);

}
