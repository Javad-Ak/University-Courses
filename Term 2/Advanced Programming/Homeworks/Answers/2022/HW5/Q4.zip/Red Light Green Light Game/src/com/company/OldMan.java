package com.company;

public class OldMan extends Character {
    private boolean isAbility;
    private final int speedIncreaseCoefficient;

    public OldMan() {
        super(75, 20, 2);
        isAbility = false;
        speedIncreaseCoefficient = 2;
    }

    @Override
    public void move(ShareData shareData) {
        super.move(shareData);
        if (isAbility) {
            super.setSpeed((super.getSpeed() / speedIncreaseCoefficient) - 2);
            isAbility = false;
        }
    }

    @Override
    public void useAbility(ShareData data) {
        if (super.wantUseAbility(data)) {
                isAbility = true;
                super.setSpeed(super.getSpeed() * speedIncreaseCoefficient);
        }
    }
}
