package com.company;

import java.util.Scanner;

public class SmartMan extends Character {
    private final int amountOfHeal;

    public SmartMan() {
        super(75, 20, 2);
        this.amountOfHeal = 25;
    }

    @Override
    public void useAbility(ShareData data) {

        if (super.wantUseAbility(data)) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Do you want to heal yourself or others??\n1.Myself\n2.Others");
            int number = scanner.nextInt();
            if (number == 1) {
                super.setHp((super.getHp() + amountOfHeal));

            } else if (number == 2) {
                System.out.println("Write the name of the person you want to heal?");
                data.printAliveUsers(this);
                String otherUser = scanner.next();
                Character character = data.getAliveCharacterByUser(otherUser);
                character.setHp((character.getHp() + amountOfHeal));
            }

        }
    }
}
