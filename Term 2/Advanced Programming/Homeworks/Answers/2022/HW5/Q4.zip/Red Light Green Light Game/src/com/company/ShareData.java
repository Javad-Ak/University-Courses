package com.company;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class ShareData {
    private ArrayList<Character> aliveCharacters;
    private HashMap<Character, String> usersCharacters;
    private HashMap<Character, String> characterRoll;
    private ArrayList<Character> winnerCharacters;
    private final int distance ;

    public ShareData() {
        this.distance = 200;
        winnerCharacters = new ArrayList<>();
        this.aliveCharacters = new ArrayList<>();
        this.usersCharacters = new HashMap<>();
        characterRoll = new HashMap<>();
        AngryMan angryMan = new AngryMan();
        this.aliveCharacters.add(angryMan);
        characterRoll.put(angryMan, "Angry Man");
        SmartMan smartMan = new SmartMan();
        this.aliveCharacters.add(smartMan);
        characterRoll.put(smartMan, "Smart Man");
        YoungGirl youngGirl = new YoungGirl();
        this.aliveCharacters.add(youngGirl);
        characterRoll.put(youngGirl, "Young Girl");
        OldMan oldMan = new OldMan();
        this.aliveCharacters.add(oldMan);
        characterRoll.put(oldMan, "Old Man");
        StrongMan strongMan = new StrongMan();
        this.aliveCharacters.add(strongMan);
        characterRoll.put(strongMan, "Strong Man");


    }

    public int getDistance() {
        return distance;
    }

    public void addWinnerCharacter(Character character){
        winnerCharacters.add(character);
    }
    public ArrayList<Character> getAliveCharacters() {
        return aliveCharacters;
    }

    public ArrayList<Character> getWinnerCharacters() {
        return winnerCharacters;
    }

    public Character getRandomAliveCharacter() {
        return aliveCharacters.get(new Random().nextInt(aliveCharacters.size()));
    }


    public void addUserCharacter(Character character, String user) {
        usersCharacters.put(character, user);
    }

    public String getUserByCharacter(Character character) {
        return usersCharacters.get(character);

    }

    public Character getAliveCharacterByUser(String user) {
        for (Character character : aliveCharacters) {
            if (usersCharacters.get(character).equals(user)) {
                return character;
            }
        }
        return null;

    }

    public void printAliveUsers(Character exceptCharacter) {
        int i = 1;
        for (Character character : aliveCharacters) {
            if (!usersCharacters.get(character).equals(usersCharacters.get(exceptCharacter))) {
                System.out.println(i + ")" + usersCharacters.get(character));
            }
        }
    }

    public void printNearAliveUsers(Character exceptCharacter, int distance) {
        int i = 1;
        for (Character character : aliveCharacters) {
            if (!usersCharacters.get(character).equals(usersCharacters.get(exceptCharacter)) &&
                    (Math.abs(character.getTraveledDistance() - exceptCharacter.getTraveledDistance()) <= distance)) {
                System.out.println(i + ")" + usersCharacters.get(character));
                i++;
            }
        }
    }

    public void printAliveCharacters() {
        for (Character character : aliveCharacters) {
            System.out.println(characterRoll.get(character) + ":" + usersCharacters.get(character));
            System.out.println(character);
        }
    }

    public void printUsersAndCharacters() {
        for (int i = 0; i < aliveCharacters.size(); i++) {
            System.out.println(i + 1 + ")" + getUserByCharacter(aliveCharacters.get(i)) +
                    ":" + characterRoll.get(aliveCharacters.get(i)));
        }
    }
}
