package com.company;

import java.util.Scanner;

public abstract class Character {
    private int hp;
    private final int maximumHP;
    private int speed;
    private int traveledDistance;
    private final int numberOfTimesCanUseAbility;
    private int numberOfTimesUsedAbility;

    public Character(int hp, int speed, int numberOfTimesCanUseAbility) {
        this.hp = hp;
        this.maximumHP = hp;
        this.speed = speed;
        this.traveledDistance = 0;
        this.numberOfTimesCanUseAbility = numberOfTimesCanUseAbility;
        this.numberOfTimesUsedAbility = 0;
    }

    public int getNumberOfTimesCanUseAbility() {
        return numberOfTimesCanUseAbility;
    }

    public int getNumberOfTimesUsedAbility() {
        return numberOfTimesUsedAbility;
    }

    public void setNumberOfTimesUsedAbility(int numberOfTimesUsedAbility) {
        this.numberOfTimesUsedAbility = numberOfTimesUsedAbility;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getSpeed() {
        return speed;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
        if (this.hp > maximumHP) {
            this.hp = maximumHP;
        } else if (this.hp < 0) {
            this.hp = 0;
        }
    }

    public int getTraveledDistance() {
        return traveledDistance;
    }

    public void move(ShareData shareData) {
        if (traveledDistance < shareData.getDistance()) {
            traveledDistance += speed;
            if (traveledDistance > shareData.getDistance()) {
                traveledDistance = shareData.getDistance();
            }
        }
    }

    public void injure(int amountOfDamage) {
        setHp(hp - amountOfDamage);

    }

    protected boolean wantUseAbility(ShareData data) {
        if (getNumberOfTimesUsedAbility() < getNumberOfTimesCanUseAbility() && getTraveledDistance() < 200) {
            Scanner scanner = new Scanner(System.in);
            String user = data.getUserByCharacter(this);
            System.out.println(user + ",do you want to use your ability?\n1.Yes\n2.No");
            int number = scanner.nextInt();
            if (number == 1) {
                setNumberOfTimesUsedAbility(getNumberOfTimesUsedAbility() + 1);
                return true;
            }
            return false;
        }
        return false;
    }

    public abstract void useAbility(ShareData data);

    @Override
    public String toString() {
        return "Character{" +
                "hp=" + hp +
                ", speed=" + speed +
                ", traveledDistance=" + traveledDistance +
                ", numberOfTimesCanUseAbility=" + numberOfTimesCanUseAbility +
                ", numberOfTimesUsedAbility=" + numberOfTimesUsedAbility +
                '}';
    }
}
