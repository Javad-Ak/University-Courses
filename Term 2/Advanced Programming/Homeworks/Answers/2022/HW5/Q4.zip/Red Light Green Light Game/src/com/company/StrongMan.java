package com.company;


public class StrongMan extends Character {
    private boolean isSafe;


    public StrongMan() {
        super(100, 25, 2);
        isSafe = false;
    }


    @Override
    public void injure(int amountOfDamage) {
        if (isSafe) {
            isSafe = false;
        } else {
            super.injure(amountOfDamage);
        }

    }

    @Override
    public void useAbility(ShareData data) {
        if (super.wantUseAbility(data)) {
            isSafe = true;
        }
    }


}
