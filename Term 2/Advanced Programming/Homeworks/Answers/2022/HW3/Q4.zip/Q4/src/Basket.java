import java.util.ArrayList;

public class Basket {

    private ArrayList<Product> products = new ArrayList<Product>();

    public void addToBasket(Product product){
        products.add(product);
    }

    public void removeFromBasket(int index) {
        if(index >= products.size()) {
            System.out.println("Invalid Index");
        } else {
            System.out.println("successfully removed.");
            products.remove(index);
        }
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    @Override
    public String toString() {
        String s = "";
        int row = 1;
        for(Product product : products) {
            s += (row + ". " + product.getName() + "  " + product.getCategory() + "  " + product.getPrice() + "$\n");
            row++;
        }
        return s;
    }
}
