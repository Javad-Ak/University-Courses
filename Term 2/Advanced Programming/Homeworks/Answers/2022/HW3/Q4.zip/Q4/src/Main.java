import java.util.Scanner;

public class Main {

    private Scanner scanner = new Scanner(System.in);
    private Store store = new Store();

    public void addInitProducts(){
        store.addAProduct("Steak", "Food", 100, 2022,3,6,21, 30,
                2022,3,9,0, 0, 5);
        store.addAProduct("Burger", "Food", 15.75F, 2022,3,3,8, 30,
                2022,3,3,20, 30, 100);
        store.addAProduct("Coffee", "Drink", 8.5F, 2022,3,1,13, 20,
                2022,3,1,15, 20, 50);
        store.addAProduct("Chocolate", "Snack", 17.99F, 2020,1,12,10, 50,
                2023,1,12,10, 50, 15);
        store.addAProduct("Snack", "Snack", 3.49F, 2021,1,14,16, 30,
                2022,1,14,16, 30, 12);
        store.addAProduct("Soda", "Drink", 7, 2022,3,11,15, 30,
                2022,6,11,15, 30, 80);
        store.addAProduct("Noodle", "Food", 35, 2022,2,28,13, 20,
                2022,4,1,0, 0, 40);
        store.addAProduct("Pizza", "Food", 19.99F, 2022,4,5,21, 00,
                2022,5,9,21, 0, 10);
    }

    public void allCommands(){
        System.out.println("[ add.p  balance  people  menu  order  checkout  basket  remove.b" +
                "  inventory(remove & change)  exit ]");
    }

    public void menu(){

        String command = scanner.next();

        switch (command){
            case "add.p":{
                String name = scanner.next();
                String username = scanner.next();
                float balance = scanner.nextFloat();
                store.addPerson(new Person(name, username, balance));
                menu();
            }

            case "balance":{
                String username = scanner.next();
                float amount = scanner.nextFloat();
                store.changeBalance(username, amount);
                menu();
            }

            case "people":{
                store.showPeople();
                menu();
            }

            case "menu":{
                store.showStocks();
                menu();
            }

            case "order":{
                String username = scanner.next();
                String foodName = scanner.next();
                store.order(username, foodName);
                menu();
            }

            case "inventory":{
                String password = scanner.next();
                if(password.equals("ceit-2022")) {
                    String partTwo = scanner.next();
                    switch (partTwo) {
                        case "remove": {
                            String name = scanner.next();
                            store.inventoryRemove(name);
                            menu();
                        }
                        case "change": {
                            String name = scanner.next();
                            int amount = scanner.nextInt();
                            store.inventoryChange(name, amount);
                            menu();
                        }
                        default:
                            menu();
                    }
                }else{
                    System.out.println("Invalid password.");
                }
                menu();
            }

            case "checkout":{
                String username = scanner.next();
                store.checkout(username);
                menu();
            }

            case "basket":{
                String username = scanner.next();
                store.showBasket(username);
                menu();
            }

            case "remove.b":{
                String username = scanner.next();
                int index = scanner.nextInt();
                store.removeBasket(username, index);
                menu();
            }

            case "exit":{
                System.out.println("Have a nice day, chief.");
                System.exit(0);
            }

            default:{
                menu();
            }

        }
    }

    public static void main(String[] args) {
        Main main = new Main();
        main.allCommands();
        main.addInitProducts();
        main.menu();
    }
}
