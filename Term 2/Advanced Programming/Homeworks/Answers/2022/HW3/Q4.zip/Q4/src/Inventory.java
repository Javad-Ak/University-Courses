import java.util.HashMap;

public class Inventory {

    private HashMap<Product, Integer> store = new HashMap<Product, Integer>();

    public void addProduct(Product product, int inStock){
        store.put(product, inStock);
    }

    public void removeProduct(Product product){
        store.remove(product);
    }

    public boolean changeInStock(Product product, int valueToChange){
        if(store.get(product) + valueToChange < 0){
            return false;
        } else {
            store.put(product, store.get(product) + valueToChange);
            return true;
        }
    }

    public Product findProduct(String name){
        for(Product product : store.keySet()){
            if(product.getName().equals(name)){
                return product;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        String str = "";
        int row = 1, sum = 0;

        for(Product product : store.keySet()){

            str += row + ". " + product.toString() + " instock: "
                    + store.get(product) + "\n";

            sum += store.get(product);
            row++;
        }

        if(sum == 0){
            return "";
        }

        return str;
    }
}
