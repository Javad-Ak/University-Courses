import java.util.Objects;

public class Person {
    private final String name;
    private final String username;
    private float balance;
    private Basket basket;

    public Person(String name, String username, float balance) {
        this.name = name;
        this.username = username;
        this.balance = balance;
        this.basket = new Basket();
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public float getBalance() {
        return balance;
    }

    public Basket getBasket() {
        return basket;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public void clearBasket() {
        basket.getProducts().clear();
    }

    @Override
    public String toString() {
        return "name= '" + name + '\'' +
                "  username= '" + username + '\'' +
                "  balance= " + balance ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return username.equals(person.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }
}
