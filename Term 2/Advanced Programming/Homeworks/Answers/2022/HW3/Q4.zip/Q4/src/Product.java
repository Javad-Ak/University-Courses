import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Product {

    private String name;
    private String category; // Snack , Food, Drink
    private float price;
    private LocalDateTime manufactureDate;
    private LocalDateTime expirationDate;

    public Product(String name, String category, float price, LocalDateTime manufactureDate, LocalDateTime expirationDate) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.manufactureDate = manufactureDate;
        this.expirationDate = expirationDate;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public float getPrice() {
        return price;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter
                = DateTimeFormatter.ofPattern(
                "yyyy-MM-dd HH:mm ");
        return "name= '" + name + '\'' +
                "  category= '" + category + '\'' +
                "  price= " + price +
                "$  manufactureDate= " + manufactureDate.format(formatter) +
                "  expirationDate= " + expirationDate.format(formatter);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return name.equals(product.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
