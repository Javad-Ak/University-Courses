import java.time.LocalDateTime;
import java.util.HashSet;

public class Store {

    private Inventory inventory;
    private HashSet<Person> people;

    public Store() {
        this.inventory = new Inventory();
        this.people = new HashSet<>();
    }

    public void showStocks(){
        if(inventory.toString().equals("")){
            System.out.println("We are out of stock.");
        }else {
            System.out.println(inventory);
        }
    }

    public void showBasket(String username){
        Person person = findPerson(username);
        if(person != null){
            if(person.getBasket().toString().equals("")) {
                System.out.println("Your basket is empty.");
            }else{
                System.out.println(person.getName() + "'s Basket: ");
                System.out.println(person.getBasket().toString());
            }
        }else{
            System.out.println("Invalid username");
        }
    }

    public void removeBasket(String username, int index){
        Person person = findPerson(username);
        if(person != null){
            person.getBasket().removeFromBasket(index-1);
        }else{
            System.out.println("Invalid username");
        }
    }

    public Person findPerson(String username){
        for(Person person : people){
            if(person.getUsername().equals(username)){
                return person;
            }
        }
        return null;
    }

    public void changeBalance(String username, float amount){
        Person person = findPerson(username);
        if(person != null){
            person.setBalance(person.getBalance() + amount);
            System.out.println("Successfully added " + amount + "$ to " + person.getUsername() + "'s account");
        }else{
            System.out.println("Invalid username.");
        }

    }

    public void showPeople(){
        int i = 1;
        if(people.size() > 0) {
            for (Person person : people) {
                System.out.println(i + ". " + person.toString());
                i++;
            }
        }else{
            System.out.println("There is no one here!");
        }
    }

    public void addPerson(Person person){
        if(people.contains(person)){
            System.out.println("This Person Already Exist.");
        }
        else{
            System.out.println("Person Added Successfully");
        }
        people.add(person);
    }

    public void order(String username, String foodName){
        Person person = this.findPerson(username);
        Product product = inventory.findProduct(foodName);
        if(person != null) {
            if (product != null) {
                if (inventory.changeInStock(product, -1)) {
                    person.getBasket().addToBasket(product);
                    System.out.println("Successfully added to your basket.");
                } else {
                    System.out.println("Out of Stock.");
                }
            } else {
                System.out.println("Invalid food.");
            }
        } else {
            System.out.println("Invalid Username!");
        }
    }

    public void inventoryRemove(String name){
        Product product = inventory.findProduct(name);
        if(product != null) {
            System.out.println("Successfully added to your basket.");
            inventory.removeProduct(product);
        } else {
            System.out.println("Invalid name!");
        }
    }

    public void inventoryChange(String name, int amount){
        Product product = inventory.findProduct(name);
        if( product != null){
            if(inventory.changeInStock(product, amount)){
                System.out.println("Successfully changed the amount.");
            } else {
                System.out.println("Greater than available amount in stock");
            }
        } else {
            System.out.println("Invalid name!");
        }
    }

    public void checkout(String username){
        Person person = findPerson(username);
        float tax = 0 , net = 0 ;
        if(person != null) {
            for (Product product : person.getBasket().getProducts()) {
                switch (product.getCategory()) {
                    case "Drink":{
                        tax += (float) (0.35 * product.getPrice());
                        net += product.getPrice();
                        continue;
                    }
                    case "Food":{
                        tax += (float) (0.10 * product.getPrice());
                        net += product.getPrice();
                        continue;
                    }
                    case "Snack":{
                        tax += (float) (0.20 * product.getPrice());
                        net += product.getPrice();
                    }
                }
            }
            System.out.println(username + "'s bill= " + (tax + net) );
            System.out.println("tax = " + tax + "  net = " + net );
            if(person.getBalance() >= (tax + net)){
                person.setBalance(person.getBalance() - tax - net);
                System.out.println("Your new balance= " + person.getBalance() + "\nHave a good day.");

                person.clearBasket();
            } else {
                System.out.println("You can't afford your bill.");
            }
        } else {
            System.out.println("Invalid username.");
        }
    }

    public void addAProduct(String name, String category, float price,
                            int yearM, int monthM, int dayM, int hourM, int minM,
                            int yearE, int monthE, int dayE, int hourE, int minE,
                            int inStock){
        Product product;
        LocalDateTime manufactureDate = LocalDateTime.of(yearM, monthM, dayM, hourM, minM);
        LocalDateTime expirationDate = LocalDateTime.of(yearE, monthE, dayE, hourE, minE);

        if(manufactureDate.compareTo(expirationDate) > 0){
            System.out.println("Invalid date input");
        } else {
            if(category.equals("Drink") || category.equals("Food") || category.equals("Snack") ) {
                product = new Product(name, category, price, manufactureDate, expirationDate);
                inventory.addProduct(product, inStock);
            } else {
                System.out.println("Invalid category input");
            }
        }
    }
}
