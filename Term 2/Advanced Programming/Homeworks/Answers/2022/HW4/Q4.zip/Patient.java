package hospital;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author  saman hazemi jebelli
 */
public class Patient {
    Scanner scanner = new Scanner(System.in);
    private final String firstName;
    private final String lastName;
    private final int age;
    private final String address;
    private ArrayList<Report> reports;
    private ArrayList<Doctor> doctors;

    public Patient(String firstName, String lastName, int age, String address, ArrayList<Doctor> doctors) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.address = address;
        reports = new ArrayList<>();
        this.doctors = doctors ;
    }

    public void menu() {
        int choice;
        do {
            System.out.println("1- View Profile \n2- Book Appointment\n3- View Report \n4- Log Out");
            choice = scanner.nextInt();
            switch (choice) {
                case 1 -> System.out.println(this);
                case 2 -> bookAppointment();
                case 3 -> selectReport();
            }
        } while(choice != 4);
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    private void bookAppointment() {
        DoctorType doctorType;
        System.out.println("1- EyesSpecialist,2- EarSpecialist,3- HeartSpecialist,4- BonesSpecialist,5- LungsSpecialist");
        int choice;
        do {
            choice = scanner.nextInt();
        } while(choice < 1 || choice > 5);
        switch (choice) {
            case 1 -> doctorType = DoctorType.EyesSpecialist;
            case 2 -> doctorType = DoctorType.EarSpecialist;
            case 3 -> doctorType = DoctorType.HeartSpecialist;
            case 4 -> doctorType = DoctorType.BonesSpecialist;
            default -> doctorType = DoctorType.LungsSpecialist;
        }
        int i = 1;
        for(Doctor doctor : doctors) {
            if(doctor.getDoctorType() == doctorType) {
                System.out.println(i + "- " + doctor.printDoctorInformation());
                i++;
            }
        }
        i--;
        if(i != 0) {
            do {
                choice = scanner.nextInt();
            } while (choice < 1 || choice > i);
            i = 1;
            for (Doctor doctor : doctors) {
                if (doctor.getDoctorType() == doctorType) {
                    if (i == choice)
                        doctor.makeAppointment(this);
                    i++;
                }
            }
        }
    }
    private void selectReport() {
        for(Report report : reports)
            System.out.println(report.printReport());
    }
    @Override
    public String toString() {
        return "Patient{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", address=" + address  +
                '}';
    }
    public String getPatientNameAndLastname() {
        return firstName + " " + lastName;
    }
    public void addReport(Report newReport) {
        reports.add(newReport);
    }
}
