package hospital;

import java.time.LocalDateTime;

/**
 * @author  saman hazemi
 * Appointment class
 */
public class Appointment {
    private String doctorsFirstName;
    private String doctorsLastName;
    private String patientsFirstName;
    private String patientsLastName;
    private Patient patient;
    DoctorType doctorType;
    LocalDateTime date;

    public Appointment(Patient patient, String doctorsFirstName, String doctorsLastName, String patientsFirstName, String patientsLastName, DoctorType doctorType, LocalDateTime date) {
        this.doctorsFirstName = doctorsFirstName;
        this.doctorsLastName = doctorsLastName;
        this.patientsFirstName = patientsFirstName;
        this.patientsLastName = patientsLastName;
        this.doctorType = doctorType;
        this.date = date;
        this.patient = patient;
    }

    public Patient getPatient() {
        return patient;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "doctorsFirstName='" + doctorsFirstName + '\'' +
                ", doctorsLastName='" + doctorsLastName + '\'' +
                ", patientsFirstName='" + patientsFirstName + '\'' +
                ", patientsLastName='" + patientsLastName + '\'' +
                ", doctorType=" + doctorType.name() +
                ", date=" + String.valueOf(date) +
                '}';
    }
}
