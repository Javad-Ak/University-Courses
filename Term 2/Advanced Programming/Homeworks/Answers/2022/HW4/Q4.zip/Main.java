package hospital;
//40031060
public class Main {
    public static void main(String[] args) {
        Hospital hospital = new Hospital();
        hospital.mainMenu();
    }
}
