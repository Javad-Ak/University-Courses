package hospital;

/**
 * @author  saman hazemi jebelli
 * Report class
 */
public class Report {
    private String doctorFirstName;
    private String doctorLastName;
    private String patientFirstName;
    private String patientLastName;
    private String medicinePrescribed;
    private String doctorsComment;

    public Report(String doctorFirstName, String doctorLastName, String patientFirstName, String patientLastName, String medicinePrescribed, String doctorsComment) {
        this.doctorFirstName = doctorFirstName;
        this.doctorLastName = doctorLastName;
        this.patientFirstName = patientFirstName;
        this.patientLastName = patientLastName;
        this.medicinePrescribed = medicinePrescribed;
        this.doctorsComment = doctorsComment;
    }

    public String printReport() {
        return "Report{" +
                "doctorFirstName='" + doctorFirstName + '\'' +
                ", doctorLastName='" + doctorLastName + '\'' +
                ", patientFirstName='" + patientFirstName + '\'' +
                ", patientLastName='" + patientLastName + '\'' +
                ", medicinePrescribed='" + medicinePrescribed + '\'' +
                ", doctorsComment='" + doctorsComment + '\'' +
                '}';
    }
}
