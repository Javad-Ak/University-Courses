package hospital;

import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author  saman hazemi jebelli
 */
public class Admin {
    Scanner scanner = new Scanner(System.in);
    private ArrayList<Doctor> doctors;
    private ArrayList<Patient> patients;
    public Admin(ArrayList<Doctor> doctors, ArrayList<Patient> patients) {
        this.doctors = doctors;
        this.patients = patients;
    }
    private void viewPatient() {
        for(Patient patient : patients)
            System.out.println(patient.toString());
    }
    private void viewDoctor() {
        for(Doctor doctor : doctors)
            System.out.println(doctor.toString());
    }
    private void addDoctor() {
        System.out.println("Enter name :");
        String name = scanner.next();
        System.out.println("Enter lastname :");
        String lastName = scanner.next();
        DoctorType doctorType;
        System.out.println("1- EyesSpecialist,2- EarSpecialist,3- HeartSpecialist,4- BonesSpecialist,5- LungsSpecialist");
        int choice;
        do {
            choice = scanner.nextInt();
        } while(choice < 1 || choice > 5);
        switch (choice) {
            case 1 -> doctorType = DoctorType.EyesSpecialist;
            case 2 -> doctorType = DoctorType.EarSpecialist;
            case 3 -> doctorType = DoctorType.HeartSpecialist;
            case 4 -> doctorType = DoctorType.BonesSpecialist;
            default -> doctorType = DoctorType.LungsSpecialist;
        }
        System.out.println("Enter age :");
        int age = scanner.nextInt();
        System.out.println("Enter entryCharge : ");
        int entryCharge = scanner.nextInt();
        doctors.add(new Doctor(name, lastName, age, doctorType, entryCharge));
        System.out.println("Added Successfully!");
    }
    public void login() {
        String password;
        System.out.println("Enter password :");
        do {
            password = scanner.next();
            if(!password.equals("123"))
                System.out.println("Wrong Password");
        } while(!password.equals("123"));
        System.out.println("Welcome");
        int choice;
        do {
            System.out.println("1- DOCTORS LIST 2- PATIENTS LIST 3- ADD DOCTOR 4- LOGOUT");
            choice = scanner.nextInt();
            switch (choice) {
                case 1 -> viewDoctor();
                case 2 -> viewPatient();
                case 3 -> addDoctor();
            }
        } while(choice != 4);
    }
}
