package hospital;
import java.util.*;

/**
 * @author  saman hazemi jebelli
 */
public class Hospital {
    private ArrayList<Doctor> doctors;
    private ArrayList<Patient> patients;
    private final Admin admin;
    private static final Scanner scanner = new Scanner(System.in);
    public Hospital() {
        doctors = new ArrayList<>();
        patients = new ArrayList<>();
        admin = new Admin(doctors, patients);
    }

    public void mainMenu() {
        int choice;
        do {
            System.out.println("1- ADMIN LOGIN\n2- PATIENT LOGIN\n3- DOCTOR LOGIN\n4- PATIENT SIGNUP\n5- EXIT");
             choice = scanner.nextInt();
             switch (choice) {
                 case 1 -> admin.login();
                 case 2 -> patientLogin();
                 case 3 -> doctorLogin();
                 case 4 -> patientSignUP();
             }
        } while(choice != 5);
    }
    private void patientLogin() {
        int i = 1;
        for(Patient patient :  patients)  {
            System.out.println(i + "- " + patient.getPatientNameAndLastname());
            i++;
        }
        i--;
        if(i != 0) {
            int choice;
            do {
                choice = scanner.nextInt();
            } while (choice > i || choice < 1);
            int j = 1;
            for (Patient patient : patients) {
                if (j == choice) {
                    patient.menu();
                    break;
                }
                j++;
            }
        }
    }
    private void doctorLogin() {
        int i = 1;
        for(Doctor doctor : doctors)  {
            System.out.println(i + "- " + doctor.printDoctorInformation());
            i++;
        }
        i--;
        if(i != 0) {
            int choice;
            do {
                choice = scanner.nextInt();
            } while (choice > i || choice < 1);
            int j = 1;
            for (Doctor doctor : doctors) {
                if (j == choice) {
                    doctor.menu();
                    break;
                }
                j++;
            }
        }
    }
    private  void patientSignUP() {
        System.out.println("Enter firstName :");
        String firstName = scanner.next();
        System.out.println("Enter lastName : ");
        String lastName = scanner.next();
        System.out.println("Enter age : ");
        int age = scanner.nextInt();
        System.out.println("Enter your address :(with out space)");
        String address = scanner.next();
        patients.add(new Patient(firstName, lastName, age, address, doctors));
    }
}
