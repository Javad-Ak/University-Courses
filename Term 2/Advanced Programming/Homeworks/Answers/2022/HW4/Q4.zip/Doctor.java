package hospital;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author  saman hazemi jebelli
 */
enum DoctorType{EyesSpecialist, EarSpecialist, HeartSpecialist, BonesSpecialist, LungsSpecialist}

/**
 * @author  saman hazemi jebelli
 */
public class Doctor {
    private final Scanner scanner =  new Scanner(System.in);
    private final String firstName;
    private final String lastName;
    private int age;
    private DoctorType doctorType;
    private int entryCharge;
    private ArrayList<Appointment> appointments;
    public void menu() {
        int choice ;
        do {
            System.out.println("1- ViewProfile\n2- ViewAppointments\n3- Log Out");
            choice = scanner.nextInt();
            switch (choice) {
                case 1 -> System.out.println(toString());
                case 2 -> selectAppointment();
            }
        }while (choice != 3);

    }
    public Doctor(String firstName, String lastName, int age, DoctorType doctorType, int entryCharge) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.doctorType = doctorType;
        this.entryCharge = entryCharge;
        this.appointments = new ArrayList<>();
    }
    public String printDoctorInformation() {
        return firstName + " " + lastName + " " + entryCharge;
    }
    public DoctorType getDoctorType() {
        return doctorType;
    }
    public void viewAppointments() {
        for(Appointment appointment : appointments)
            System.out.println(appointment.toString());
    }
    public void makeAppointment(Patient patient) {
        Appointment newAppointment = new Appointment(patient, firstName, lastName, patient.getFirstName(), patient.getLastName(), doctorType, LocalDateTime.now());
        appointments.add(newAppointment);
        System.out.println(newAppointment.toString());
    }
    private void selectAppointment() {
        int i = 1;
        for(Appointment appointment : appointments) {
            System.out.println(i + "- " + appointment.toString());
            i++;
        }
        i--;
        if(i > 0) {
            int choice;
            do {
                choice = scanner.nextInt();
            } while (choice < 1 || choice > i);
            Patient patient = null;
            i = 1;
            for (Appointment appointment : appointments) {
                if (i == choice) {
                    patient = appointment.getPatient();
                }
                i++;
            }
            System.out.println("Enter medicine :");
            String medicine = scanner.next();
            System.out.println("Enter comment :");
            String comment = scanner.next();
            Report newReport = new Report(firstName, lastName, patient.getFirstName(), patient.getLastName(), medicine, comment);
            patient.addReport(newReport);
        }
    }
    @Override
    public String toString() {
        return "Doctor{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", doctorType=" + doctorType.name() +
                ", entryCharge=" + entryCharge +
                '}';
    }
}
