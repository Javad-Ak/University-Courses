package Solution;

import java.util.Scanner;

/* Example:
    Enter a number between 1 and 100: 50
    Your guess is too low.
    Enter a number between 1 and 100: 75
    Your guess is too low.
    Enter a number between 1 and 100: 87
    Your guess is too low.
    Enter a number between 1 and 100: 93
    Your guess is too low.
    Enter a number between 1 and 100: 96
    Your guess is too low.
    Enter a number between 1 and 100: 99
    Your guess is too low.
    Enter a number between 1 and 100: 100
    You guessed the number!
 */

public class Main {
    public static void main(String[] args) {
        GuessingGame game = new GuessingGame();
        Scanner input = new Scanner(System.in);
        int userNumber;
        while (true) {
            System.out.print("Enter a number between 1 and 100: ");
            userNumber = input.nextInt();
            if (game.compareInput(userNumber)){
                return;
            }
            if (!game.checkCounter()) {
                System.out.println("You have used up all your guesses.");
                return;
            }
        }
    }
}