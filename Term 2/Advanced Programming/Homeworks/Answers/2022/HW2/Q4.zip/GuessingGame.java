package Solution;

public class GuessingGame {
    private final int computerNumber;
    private int counter = 0;

    public GuessingGame() {
        computerNumber = (int) (Math.random() * 100) + 1;
    }

    public boolean compareInput(int userNumber) {
        if (userNumber == computerNumber) {
            System.out.println("You guessed the number!");
            return true;
        } else if (userNumber > computerNumber) {
            System.out.println("Your guess is too high.");
        } else {
            System.out.println("Your guess is too low.");
        }
        return false;
    }

    public boolean checkCounter() {
        counter++;
        return counter < 7;
    }
}
