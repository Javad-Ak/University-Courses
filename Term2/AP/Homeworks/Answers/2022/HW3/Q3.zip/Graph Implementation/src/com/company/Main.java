package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Graph graph = new Graph();
        while (true) {
            String[] inputString = scanner.nextLine().split(" ");
            if (inputString[0].equals("addVertex")) {
                int vertex = Integer.parseInt(inputString[1]);
                graph.addVertex(vertex);
            } else if (inputString[0].equals("addEdge")) {
                int source = Integer.parseInt(inputString[1]);
                int destination = Integer.parseInt(inputString[2]);
                graph.addEdge(source, destination);

            } else if (inputString[0].equals("removeEdge")) {
                int source = Integer.parseInt(inputString[1]);
                int destination = Integer.parseInt(inputString[2]);
                graph.removeEdge(source, destination);

            } else if (inputString[0].equals("print")) {
                graph.printGraph();

            } else if (inputString[0].equals("exit")) {
                return;
            }
        }
    }
}



