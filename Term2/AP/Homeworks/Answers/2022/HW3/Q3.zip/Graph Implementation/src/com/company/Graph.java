package com.company;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Graph {
    private HashMap<Integer, ArrayList<Integer>> adjacencyMap;

    public Graph() {
        adjacencyMap = new HashMap<>();
    }

    public void addVertex(int vertex) {
        adjacencyMap.put(vertex, new ArrayList<>());
    }

    public void addEdge(int source, int destination) {
        if (!adjacencyMap.containsKey(source)) {
            addVertex(source);
        }
        if (!adjacencyMap.containsKey(destination)) {
            addVertex(destination);
        }
        if (!adjacencyMap.get(source).contains(destination)) {
            adjacencyMap.get(source).add(destination);
        }

    }

    public void removeEdge(int source, int destination) {
        if (adjacencyMap.get(source) != null) {
            if (adjacencyMap.get(source).contains(destination)) {
                adjacencyMap.get(source).remove(Integer.valueOf(destination));
            }
        }
    }

    public void printGraph() {
        ArrayList<Integer> vertices = new ArrayList<>(adjacencyMap.keySet());
        Collections.sort(vertices);
        System.out.print("Graph {\n");
        for (int vertex : vertices) {
            ArrayList<Integer> adjacencyVertices = adjacencyMap.get(vertex);
            System.out.print(vertex + " : ");
            for (int adjacencyVertex : adjacencyVertices) {
                System.out.print(adjacencyVertex + " ");
            }
            System.out.println();

        }
        System.out.println("}");
    }
}