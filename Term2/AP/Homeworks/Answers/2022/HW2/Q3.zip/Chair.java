// BWOTSHEWCHB

public class Chair {
	// Fields
	private boolean isEmpty;
	// Constructors
	public Chair() {
		this.isEmpty = true;
	}
	// Setters
	public void changeState() {
		this.isEmpty = !this.isEmpty;
	}
	// Getters
	public boolean getState() {
		return this.isEmpty;
	}
}

