// BWOTSHEWCHB

public class Row {
	// Fields
	private Chair[] left;
	private Chair[] middle;
	private Chair[] right;
	// Constructors
	public Row() {
		this.left = new Chair[3];
		for ( int column = 0; column < 3; column += 1 ) {
			this.left[column] = new Chair();
		}

		this.middle = new Chair[4];
		for ( int column = 0; column < 4; column += 1 ) {
			this.middle[column] = new Chair();
		}

		this.right = new Chair[3];
		for ( int column = 0; column < 3; column += 1 ) {
			this.right[column] = new Chair();
		}
	}
	// Setters
	public void setChair(int column) {
		// convert to 0-based
		column -= 1 ;

		if ( column < 0 ) {
			// invalid column index
		} 
		if ( column >= 0 && column < 3 ) {
			this.getLeft(column).changeState();
		}
		if ( column >= 3 && column < 7 ) {
			this.getMiddle(column - 3).changeState();
		}
		if ( column >= 7 && column < 10 ) {
			this.getRight(column - 7).changeState();
		}
		if ( column >= 10 ) {
			// invalid column index
		}
	}
	// Getters
	private Chair getLeft(int column) {
		return this.left[column];
	}
	private Chair getMiddle(int column) {
		return this.middle[column];
	}
	private Chair getRight(int column) {
		return this.right[column];
	}
	public boolean getChair(int column) {
		// convert to 0-based
		column -= 1;

		if ( column < 0 ) {
			// invalid column index (returns false)
			return false;
		}
		if ( column >= 0 && column < 3 ) {
			return this.getLeft(column).getState();
		}
		if ( column >= 3 && column < 7 ) {
			return this.getMiddle(column - 3).getState();
		}
		if ( column >= 7 && column < 10 ) {
			return this.getRight(column - 7).getState();
		}
		if ( column >= 10 ) {
			// invalid column index (returns false)
			return false;
		}

		return false;
	}
}

