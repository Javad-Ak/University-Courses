// BWOTSHEWCHB

public class Cinema {
	// Fields
	private int size;
	private Row[] rows;
	// Constructors
	public Cinema(int size) {
		this.size = size;
		this.rows = new Row[size];
		for ( int row = 0; row < size; row += 1 ) {
			this.rows[row] = new Row();
		}
	}
	// Setters
	private void setChair(int row, int column) {
		// convert to 0-based
		row -= 1;

		if ( row < 0 ) {
			// invalid row index
		}
		if ( row >= 0 && row < size ) {
			this.getRow(row).setChair(column);
		}
		if ( row >= size ) {
			// invalid row index
		}
	}
	public void occupyChairs(int left, int right, int row) {
		for ( int column = left; column <= right; column += 1 ) {
			this.setChair(row, column);
		}
	}
	// Getters
	private Row getRow(int row) {
		return this.rows[row];
	}
	private boolean getChair(int row, int column) {
		// convert to 0-based
		row -= 1;

		if ( row < 0 ) {
			// invalid row index
			return false;
		}
		if ( row >= 0 && row < size ) {
			return this.getRow(row).getChair(column);
		}
		if ( row >= size ) {
			// invalid row index
			return false;
		}

		return false;
	}
	public boolean checkChairs(int left, int right, int row) {
		boolean canSit = true;
		for ( int column = left; column <= right; column += 1 ) {
			if ( this.getChair(row, column) == false ) {
				canSit = false;
			}
		}

		return canSit;
	}
}

