// BWOTSHEWCHB

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int Q, N;
		Q = scanner.nextInt();
		N = scanner.nextInt();

		int l, r, x;
		Cinema cinema = new Cinema(N);
		for ( int it = 0; it < Q; it += 1 ) {
			l = scanner.nextInt();
			r = scanner.nextInt();
			x = scanner.nextInt();

			boolean canSit = cinema.checkChairs(l, r, x);
			if ( canSit ) {
				cinema.occupyChairs(l, r, x);
			}

			System.out.println(canSit);
		}
	}
}

