package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;

/**
 * this class is defined to describe each UNO player by its score and the list of cards
 */
public class Player {
    protected int score;
    protected Hand hand;
    protected String name;
    /**
     * the new players' scores are 0 at first
     */
    public Player(){
        this.score=0;
        hand=new Hand();
    }

    /**
     * setting a hand for the player
     * @param handToSet
     */
    public void setHand(Hand handToSet){
        this.hand=handToSet;
    }

    /**
     * getting a player's hand
     * @return
     */
    public Hand getHand(){
        return hand;
    }

    /**
     * playing a turn if possible
     * @param lastCard
     * @return
     */
    public Card playaTurn(Card lastCard){
        if(this instanceof User){
            ((User) this).displayHand();
        }
        if(!ableToPlay(lastCard)){
            System.out.println("Oops");
            return null;
        }
        return chooseCard(lastCard);
    }

    public boolean ableToPlay(Card lastCard){
        if(hand.voidInColor(lastCard.getColor()) && hand.voidInChar(lastCard.getValue())){
            return false;
        }
        return true;
    }

    public void removeCard(Card toRemove){
        hand.removeCard(toRemove);
    }

    public Color chooseColor(){
        return null;
    }

    /**
     * choose a card to play if possible
     * @param lastCard
     * @return
     */
    public Card chooseCard(Card lastCard) {
        return null;
    }

    /**
     * getting a player's name
     * @return
     */
    public String getName(){
        return name;
    }

    /**
     * setting a score at the end of the game
     */
    public void setScore(){
        score=hand.calculateScore();
    }

    /**
     * to get a player's score at the end of the game
     * @return
     */
    public int getScore(){
        return score;
    }
}
