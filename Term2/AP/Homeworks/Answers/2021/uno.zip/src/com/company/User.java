package com.company;

import java.util.Scanner;

/**
 * this class is defined to describe a user player
 */
public class User extends Player {
    /**
     * making a new usert player
     * @param name
     */
    public User(String name){
        super();
        this.name=name;
    }

    /**
     * displaying a user player's hand
     */
    public void displayHand(){
        hand.display();
        for(int i=0;i<hand.getCards().size();i++){
            if(i>=9){
                System.out.print("    "+(i+1)+"    ");
            }
            else
                System.out.print("    "+(i+1)+"     ");
        }
        System.out.println();
    }

    /**
     * choosing a card to play
     * @param lastCard
     * @return
     */
    @Override
    public Card chooseCard(Card lastCard){
        Scanner userScanner=new Scanner(System.in);
        System.out.println();
        Card chosen = null;
        while (true){
            System.out.println("choose a card");
            int chosenCardIndex=userScanner.nextInt();
            if(chosenCardIndex<1 || chosenCardIndex>hand.getCards().size()){
                System.out.print("invalid choice");
//                continue;
            }
            else {
                chosen=hand.getCards().get(chosenCardIndex-1);
                break;
            }
        }
        return chosen;
    }


    @Override
    public Color chooseColor() {
        System.out.println("Choose Color");
        System.out.println("1) Red 2) Blue 3) Green 4) Yellow");
        Scanner scanner = new Scanner(System.in);
        int chosen = scanner.nextInt();
        Color retVal = null;
        switch (chosen) {
            case 1:
                retVal = Color.RED;
                break;
            case 2:
                retVal=Color.BLUE;
                break;
            case 3:
                retVal = Color.GREEN;
                break;
            case 4:
                retVal = Color.YELLOW;
                break;
        }
        return retVal;
    }
}
