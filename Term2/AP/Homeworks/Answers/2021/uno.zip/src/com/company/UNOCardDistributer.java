package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 * this class is defined to hold all of the cards necessary for UNO
 * it also distributes the cards between players
 * it puts the remaining cards in the game's deck
 */
public class UNOCardDistributer {
    ArrayList<Card> allOfCards;

    /**
     * In order to make a new distributer, we should add all of the cards to the list
     */
    public UNOCardDistributer(){
        allOfCards=new ArrayList<>();
        initCards();
    }

    /**
     * this method compeletes the list of cards when initializing a distributer
     */
    private void initCards(){
        for(int i = 1 ; i<=9 ; i++){
            if(i == 7){
                allOfCards.add(new ActionCard(Color.RED, (char)(i+'0') , 10, Action.DRAW2));
                allOfCards.add(new ActionCard(Color.BLUE, (char)(i+'0') , 10, Action.DRAW2));
                allOfCards.add(new ActionCard(Color.GREEN, (char)(i+'0') , 10, Action.DRAW2));
                allOfCards.add(new ActionCard(Color.YELLOW, (char)(i+'0') , 15, Action.DRAW4));
                continue;
            }
            else if(i==8){
                allOfCards.add(new ActionCard(Color.RED, (char)(i+'0'), 8, Action.REPEAT));
                allOfCards.add(new ActionCard(Color.BLUE, (char)(i+'0'), 8, Action.REPEAT));
                allOfCards.add(new ActionCard(Color.GREEN, (char)(i+'0'), 8, Action.REPEAT));
                allOfCards.add(new ActionCard(Color.YELLOW, (char)(i+'0'), 8, Action.REPEAT));
                continue;
            }
            else if(i==9){
                allOfCards.add(new ActionCard(Color.RED, (char)(i+'0'), 10, Action.REVERSE));
                allOfCards.add(new ActionCard(Color.BLUE, (char)(i+'0'), 10, Action.REVERSE));
                allOfCards.add(new ActionCard(Color.GREEN, (char)(i+'0'), 10, Action.REVERSE));
                allOfCards.add(new ActionCard(Color.YELLOW, (char)(i+'0'), 10, Action.REVERSE));
                continue;
            }
            allOfCards.add(new Card(Color.RED, (char)(i+'0'), i));
            allOfCards.add(new Card(Color.BLUE, (char)(i+'0'), i));
            allOfCards.add(new Card(Color.GREEN, (char)(i+'0'), i));
            allOfCards.add(new Card(Color.YELLOW, (char)(i+'0'), i));
        }
        allOfCards.add(new ActionCard(Color.RED, 'A', 11, Action.SKIP));
        allOfCards.add(new ActionCard(Color.BLUE,'A', 11, Action.SKIP));
        allOfCards.add(new ActionCard(Color.GREEN,'A', 11, Action.SKIP));
        allOfCards.add(new ActionCard(Color.YELLOW,'A', 11, Action.SKIP));
        allOfCards.add(new ActionCard(Color.RED, (char)'B', 12, Action.CHOOSE_COLOR));
        allOfCards.add(new ActionCard(Color.BLUE, (char)'B', 12, Action.CHOOSE_COLOR));
        allOfCards.add(new ActionCard(Color.GREEN, (char)'B', 12, Action.CHOOSE_COLOR));
        allOfCards.add(new ActionCard(Color.YELLOW, (char)'B', 12, Action.CHOOSE_COLOR));
        allOfCards.add(new Card(Color.RED, 'C', 12));
        allOfCards.add(new Card(Color.BLUE, 'C', 12));
        allOfCards.add(new Card(Color.GREEN, 'C', 12));
        allOfCards.add(new Card(Color.YELLOW, 'C', 12));
        allOfCards.add(new Card(Color.RED, 'D', 13));
        allOfCards.add(new Card(Color.BLUE, 'D', 13));
        allOfCards.add(new Card(Color.GREEN, 'D', 13));
        allOfCards.add(new Card(Color.YELLOW, 'D', 13));
    }

    /**
     * giving 7 cards to each player as the game starts
     * @param playerToGiveHand
     */
    public void giveAHand(Player playerToGiveHand, int num){
        Hand temp=new Hand();
        Random handRandomizer=new Random();
        for(int i=0;i< num;i++){
            int index=handRandomizer.nextInt(allOfCards.size()-1);
            temp.addCard(allOfCards.get(index));
            allOfCards.remove(allOfCards.get(index));
        }
        playerToGiveHand.setHand(temp);
    }

    /**
     * when a player chooses a card to play, this card will be added to the list
     * @param cardToAdd
     */
    public void addCard(Card cardToAdd){
        allOfCards.add(cardToAdd);
    }

    /**
     * making a shuffle order for the cards
     */
    public void shuffle(){
        Collections.shuffle(allOfCards);
    }

    /**
     * getting the main card of the game
     * @return the last card of the collection
     */
    public Card getLastCard(){
        return allOfCards.get(allOfCards.size()-1);
    }

    /**
     * to see if the previous draw card has done its task
     * @return false if it's not done yet, true otherwise
     */
    public boolean previousDraw(){
        if(allOfCards.get(allOfCards.size()-2) instanceof ActionCard
        && (((ActionCard) allOfCards.get(allOfCards.size()-2)).getAction()==Action.DRAW2 || ((ActionCard) allOfCards.get(allOfCards.size() - 2)).getAction()==Action.DRAW4)
        && !((ActionCard) allOfCards.get(allOfCards.size()-2)).getActionIsDone())
            return false;
        return true;
    }

    /**
     * giving cards to the players during the game
     * @param playerToGiveCard
     */
    public void giveFineCard(Player playerToGiveCard){
        playerToGiveCard.getHand().addCard(allOfCards.get(0));
        allOfCards.remove(0);
    }
}
