package com.company;

import java.util.ArrayList;

/**
 * this class is defined to describe game cards, by their colors
 */
public class Card {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    protected Color color;
    protected char value;
    protected int score;
    /**
     * making a new card with a specific color
     * @param color as the chosen color
     */
    public Card(Color color, char value, int score){
        this.color=color;
        this.value=value;
        this.score = score;
    }

    /**
     * getting a card's color
     * @return color
     */
    public Color getColor() {
        return color;
    }


    public char getValue(){
        return value;
    }

    /**
     * changing a card's color when it is wild
     * @param colorToSet
     */
    public void setColor(Color colorToSet){
        this.color=colorToSet;
    }

    /**
     * displayin a line of the 4-line appearance of the card
     * @param lineIndex
     */
    public void displayALine(int lineIndex){
            System.out.print(cardDisplayLines(color).get(lineIndex));
    }

    /**
     * this method creates a list of strings for displaying a card line by line(4 lines for each card)
     * @param color
     * @return
     */
    private ArrayList<String> cardDisplayLines(Color color){
        ArrayList<String> result=new ArrayList<>();
        String displayingColor;
        if(color==Color.RED)
            displayingColor=ANSI_RED;
        else if(color==Color.BLUE)
            displayingColor=ANSI_BLUE;
        else if(color==Color.GREEN)
            displayingColor=ANSI_GREEN;
        else if (color==Color.YELLOW)
            displayingColor=ANSI_YELLOW;
        else
            displayingColor=ANSI_RESET;
        result.add(displayingColor+"|$$$$$$$|"+ANSI_RESET);
        result.add(displayingColor+"|"+value+"      |"+ANSI_RESET);
        result.add(displayingColor+ "|      " + value+ "|"+ANSI_RESET);
        result.add(displayingColor+"|$$$$$$$|"+ANSI_RESET);
        return result;
    }

    public int getScore(){
        return score;
    }
    public void setScore(int score) {
        this.score = score;
    }
}
