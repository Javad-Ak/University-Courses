package com.company;

public enum Color {
    RED,
    BLUE,
    GREEN,
    YELLOW
}
