package com.company;

public enum Action {
    DRAW2,
    DRAW4,
    REPEAT,
    REVERSE,
    SKIP,
    CHOOSE_COLOR
}
