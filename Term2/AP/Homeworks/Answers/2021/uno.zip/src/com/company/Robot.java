package com.company;

/**
 * this class is defined to describe robot(computer) as a kind of player
 */
public class Robot extends Player {
    /**
     * making a new robot
     * @param i
     */
    public Robot(int i){
        super();
        if (i%10==0)
            name=i+1+"st robot";
        else if(i%10==1)
            name=i+1+"nd robot";
        else if (i%10==2)
            name=i+1+"rd robot";
        else
            name=i+1+"th robot";
    }

    /**
     * making computer's choice as a player
     * in a way that computer can choose a card which has the maximum value
     * @param lastCard
     * @return
     */
    @Override
    public Card chooseCard(Card lastCard) {
        for (Card card : hand.getCards()){
            if(lastCard.getColor() == card.getColor()){
                return card;
            }
            else if(lastCard.getValue() == card.getValue()){
                return card;
            }
        }
        return null;
    }

    @Override
    public Color chooseColor() {
        int[] num = new int[4];
        Color retVal = Color.RED;
        for (int i = 0; i<4 ; i++){
            num[i] = 0;
        }
        for (Card card: hand.getCards()){
            if(card.getColor() == Color.RED){
                num[0]++;
            }
            else if(card.getColor() == Color.BLUE){
                num[1]++;
            }
            else if(card.getColor() == Color.GREEN){
                num[2]++;
            }
            else if(card.getColor() == Color.YELLOW){
                num[3]++;
            }
        }
        int max = num[0];
        int index = 0;
        for (int i = 1; i<4; i++){
            if(num[i] > max){
                max=num[i];
                index=i;
            }
        }
        switch (index){
            case 0:
                retVal = Color.RED;
                break;
            case 1:
                retVal = Color.BLUE;
                break;
            case 2:
                retVal = Color.GREEN;
                break;
            case 3:
                retVal = Color.YELLOW;
        }
        return retVal;

    }
}

