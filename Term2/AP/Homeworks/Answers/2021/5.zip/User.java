import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;

public class User {
    private final String ID;
    private final String FIRST_NAME;
    private final String LAST_NAME;
    private String password;
    private final ArrayList<Account> accounts;


    public User(String id, String first_name, String last_name, String password) {
        ID = id;
        FIRST_NAME = first_name;
        LAST_NAME = last_name;
        this.password = password;
        accounts = new ArrayList<>();
    }

    public void addAccount(String type, int balance) {
        accounts.add(new Account(ID, FIRST_NAME, LAST_NAME, type, balance));
    }

    public void addAccount(Account account) {
        if (!account.getID().equals(ID) || !account.getFIRST_NAME().equals(FIRST_NAME) || !account.getLAST_NAME().equals(LAST_NAME)) {
            System.out.println("User And Account Information Doesn't Match!");
            return;
        }

        if (contains(account)) {
            System.out.println("Account Already Exists");
            return;
        }

        accounts.add(account);
    }

    public void removeAccount(String serial) {
        accounts.removeIf(account -> account.getSERIAL().equals(UUID.fromString(serial)));
    }

    public void removeAccount(Account toRemove) {
        accounts.removeIf(account -> account.equals(toRemove));
    }

    public void deposit(String serial, int amount) {
        Account temp = findAccount(serial);

        if (temp != null) {
            temp.updateBalance(amount);
            temp.addTransaction(new Transaction(amount));
        }
    }

    public void deposit(Account account, int amount) {
        if (!contains(account)) {
            System.out.println("User And Account Information Doesn't Match!");
            return;
        }

        account.updateBalance(amount);
        account.addTransaction(new Transaction(amount));
    }

    public void withdrawal(String serial, int amount) {
        Account temp = findAccount(serial);

        if (temp != null) {
            temp.updateBalance(-amount);
            temp.addTransaction(new Transaction(-amount));
        }
    }

    public void withdrawal(Account account, int amount) {
        if (!contains(account)) {
            System.out.println("User And Account Information Doesn't Match!");
            return;
        }

        account.updateBalance(-amount);
        account.addTransaction(new Transaction(-amount));
    }

    public void transfer(Account src, Account dest, int amount) {
        if (src == null || dest == null) {
            System.out.println("Invalid Inputs!");
            return;
        }

        if (!contains(src)) {
            System.out.println("Source Account Doesn't Belong To This User!");
            return;
        }

        src.updateBalance(-amount);
        src.addTransaction(new Transaction(-amount));
        dest.updateBalance(+amount);
        dest.addTransaction(new Transaction(+amount));
    }

    public void checkBalance(String serial) {
        Account temp = findAccount(serial);

        if (temp != null) System.out.println("Account Balance With Serial " + serial + " -> " + temp.getBalance());
    }

    public void checkBalance(Account account) {
        if (!contains(account)) {
            System.out.println("User And Account Information Doesn't Match!");
            return;
        }

        System.out.println("Account Balance With Serial " + account.getSERIAL() + " -> " + account.getBalance());
    }

    public void printAllAvailableAccount() {
        Iterator<Account> it = accounts.iterator();

        while (it.hasNext()) it.next().printAccountData();
    }

    public void printUserData() {
        System.out.println("User{" +
                "ID='" + ID + '\'' +
                ", FIRST_NAME='" + FIRST_NAME + '\'' +
                ", LAST_NAME='" + LAST_NAME + '\'' +
                ", Accounts Size='" + accounts.size() + '\'' +
                '}');
    }

    public Account findAccount(String serial) {
        UUID serialUUID = UUID.fromString(serial);
        for (Account account : accounts) {
            if (account.getSERIAL().equals(serialUUID)) return account;
        }

        return null;
    }

    public Account findAccount(int index) {
        return accounts.get(index);
    }

    public Account getLastAccount() {
        return accounts.get(accounts.size() - 1);
    }

    private boolean contains(String serial) {
        UUID serialUUID = UUID.fromString(serial);
        for (Account account : accounts) {
            if (account.getSERIAL().equals(serialUUID)) return true;
        }

        return false;
    }

    private boolean contains(Account account) {
        return accounts.contains(account);
    }

    //getter setter
    public String getID() {
        return ID;
    }

    public String getPassword() {
        return password;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(ID, user.ID) && Objects.equals(FIRST_NAME, user.FIRST_NAME) && Objects.equals(LAST_NAME, user.LAST_NAME);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID, FIRST_NAME, LAST_NAME);
    }
}
