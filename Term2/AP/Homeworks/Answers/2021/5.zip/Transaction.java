import java.util.Date;

public class Transaction {
    private final int AMOUNT;
    private final Date DATE;

    public Transaction(int amount) {
        this.AMOUNT = amount;
        this.DATE = new Date();
    }

    public void print() {
        System.out.println("Dear Customer, New Changes Were Made On Your Account Balance With The Amount Of "
                + AMOUNT + "$ On " + DATE.toString());
    }
}
