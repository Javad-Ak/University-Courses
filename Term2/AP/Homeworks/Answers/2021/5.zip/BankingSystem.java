import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.UUID;

public class BankingSystem {
    private final ArrayList<User> users;
    private final ArrayList<Account> accounts;

    public BankingSystem() {
        accounts = new ArrayList<>();
        users = new ArrayList<>();
    }

    public void register(User user) {
        if (containsUser(user.getID())) {
            System.out.println("USER ALREADY EXISTS!");
            return;
        }

        addUser(user);
    }

    public User login(String id, String password) {
        User temp = findUser(id);

        if (temp == null) {
            System.out.println("USER DOESN'T EXIST!");
            return null;
        }

        if (!temp.getPassword().equals(password)) {
            System.out.println("INCORRECT PASSWORD!");
            return null;
        }

        return temp;
    }

    public void addUser(User user) {
        this.users.add(user);
    }

    public void removeUser(String id)
    {
        User toRemove = null;
        for(User user: users)
            if(user.getID().equals(id))
            {
                toRemove = user;
                break;
            }
        if(toRemove != null)
            for(Account acc : toRemove.getAccounts())
                accounts.removeIf(temp -> temp.equals(acc));
        users.removeIf(user -> user.getID().equals(id));
    }

    public void removeUser(User toRemove) {
        for(Account acc : toRemove.getAccounts())
            accounts.removeIf(temp -> temp.equals(acc));
        users.removeIf(user -> user.equals(toRemove));
    }

    public void addAccount(Account account) {
        if (containsAccount(account.getSERIAL().toString())) return;
        for(User user: users)
        {
            if(user.getID().equals(account.getID()))
                user.addAccount(account);
        }
        this.accounts.add(account);
    }

    public void removeAccount(String serial) {
        UUID serialUUID = UUID.fromString(serial);
        for(User user: users)
        {
            user.getAccounts().removeIf(temp -> temp.getSERIAL().equals(serialUUID));
        }
        accounts.removeIf(account -> account.getSERIAL().equals(serialUUID));
    }

    public void removeAccount(Account toRemove) {
        for(User user: users)
        {
            user.getAccounts().removeIf(temp -> temp.equals(toRemove));
        }
        accounts.removeIf(account -> account.equals(toRemove));
    }

    public Account findAccount(String serial) {
        UUID serialUUID = UUID.fromString(serial);

        for (Account account : accounts) {
            if (account.getSERIAL().equals(serialUUID)) return account;
        }

        return null;
    }

    public void displayUsers() {

        for (User user : users) user.printUserData();
    }

    public void displayAccounts() {
        Iterator<Account> it = accounts.iterator();

        while (it.hasNext()) it.next().printAccountData();
    }

    private boolean containsUser(String id) {
        for (User user : users) {
            if (user.getID().equals(id)) return true;
        }

        return false;
    }

    private boolean containsAccount(String serial) {
        UUID serialUUID = UUID.fromString(serial);

        for (Account account : accounts) {
            if (account.getSERIAL().equals(serialUUID)) return true;
        }

        return false;
    }

    private User findUser(String id) {
        for (User user : users) {
            if (user.getID().equals(id)) return user;
        }

        return null;
    }
}
