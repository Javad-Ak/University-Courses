import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;

public class Account {
    private final UUID SERIAL;
    private final String ID;
    private final String FIRST_NAME;
    private final String LAST_NAME;
    private final String TYPE;
    private int balance;
    private final ArrayList<Transaction> transactions;

    public Account(String id, String first_name, String last_name, String type, int balance) {
        SERIAL = UUID.randomUUID();
        ID = id;
        this.FIRST_NAME = first_name;
        this.LAST_NAME = last_name;
        TYPE = type;
        this.balance = balance;
        transactions = new ArrayList<>();
    }

    public void updateBalance(int amount) {
        if (this.balance + amount < 0) {
            System.out.println("You Don't Have Enough Cash!");
            return;
        }

        this.balance += amount;
        addTransaction(new Transaction(amount));
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }

    public void printTransactions() {
        Iterator<Transaction> it = transactions.iterator();

        while (it.hasNext()) {
            it.next().print();
        }
    }

    public void printAccountData() {
        System.out.println("Account {" +
                "SERIAL = " + SERIAL +
                ", ID='" + ID + '\'' +
                ", FIRST_NAME = '" + FIRST_NAME + '\'' +
                ", LAST_NAME = '" + LAST_NAME + '\'' +
                ", TYPE = '" + TYPE + '\'' +
                ", Balance = " + balance +
                '}');
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return Objects.equals(SERIAL, account.SERIAL) && Objects.equals(ID, account.ID) && Objects.equals(FIRST_NAME, account.FIRST_NAME) && Objects.equals(LAST_NAME, account.LAST_NAME) && Objects.equals(TYPE, account.TYPE);
    }

    @Override
    public int hashCode() {
        return Objects.hash(SERIAL, ID, FIRST_NAME, LAST_NAME, TYPE);
    }

    public UUID getSERIAL() {
        return SERIAL;
    }

    public String getID() {
        return ID;
    }

    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    public String getLAST_NAME() {
        return LAST_NAME;
    }

    public String getTYPE() {
        return TYPE;
    }

    public int getBalance() {
        return balance;
    }
}

